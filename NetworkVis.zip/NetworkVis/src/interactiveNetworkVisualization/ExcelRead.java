package interactiveNetworkVisualization;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class ExcelRead {

	int sizeX;
	int sizeY;
	String path;
	String[][] xlsData;
	InputStream inp=null;
	Workbook wb=null;
	Sheet sheet;
	
	// pass path in constructor
	public ExcelRead(String filepath) {
		this.path = filepath;

	}
	
	public void createReader() {
		  try {
			    inp = new FileInputStream(path);
			  }
			  catch(Exception e) {
			  }
			  try {
			    wb = WorkbookFactory.create(inp);
			  }
			  catch(Exception e) {
			  }
			  sheet = wb.getSheetAt(0);
	}
	
	public int[] getDimensions() {

		  
		  sizeY = sheet.getLastRowNum()+1; // +1 for index convention
		  sizeX = sheet.getRow(0).getLastCellNum();
		  
		  int[] xlsDim = new int[2];
		  xlsDim[0] = sizeX;
		  xlsDim[1] = sizeY;
		  return xlsDim;
	}
	
	public String[][] getxlsData() {
		 xlsData = new String[sizeX-1][sizeY];
		  for (int i=0; i<sizeX; ++i) {
		    for (int j=0; j<sizeY-1; ++j) {
		      Row row = sheet.getRow(j+1);
		      try {
		        Cell cell = row.getCell(i);		        
		        if (cell.getCellType()==1)			       
		        	xlsData[i][j] = cell.getStringCellValue();
		      }
		      catch(Exception e) {
		      }
		    }
		  }			  
		  System.out.println("Excel file imported successfully!");	
		  return xlsData;
	}
	
	
}
