package interactiveNetworkVisualization;

import java.io.File;
import java.util.TimerTask;
/**
 *  Filewatcher is working but hasn't yet been implemented as part of the main class file.
 */
public class FileWatcher extends TimerTask {
	  long timeStamp;
	  File file;
	  String path;	  

	  FileWatcher( File _file, String _path) {
	    this.file = _file;
	    this.timeStamp = file.lastModified();
	    this.path = _path;	    
	  }
	@Override
	public void run() {
	    long timeStamp = file.lastModified();

	    if ( this.timeStamp != timeStamp ) {	    	
	    	this.timeStamp = timeStamp;
	    	onChange(file);	    		    		  	        	
	    }
	  }
		  
	  void onChange( File file ) {		  
		// Do stuff here
	  }

	}


