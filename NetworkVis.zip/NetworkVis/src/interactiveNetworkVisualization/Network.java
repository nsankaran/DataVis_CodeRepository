package interactiveNetworkVisualization;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;
/**
 * Handles the nuts and bolts of network analysis. Finds unique nodes in the data,
 * constructs an adjacency matrix, uses this to compute network parameters (degree/connectivity,
 * clustering coefficient). Many more measures can be added to this list to give the
 * user more visualization options.
 *  
 * @author narayansankaran
 *
 */
public class Network {
	
	String[][] xlsData;
	String[] names;
	boolean[][] Adjacency;
	int numVertices;
	int edgeCount;
	
	
	public Network(String[][] _xlsData) {
		xlsData = _xlsData;
	}
	
	public String[] getNodeList() {
		  // create 1d array of values
		  String[] xls1 = new String[xlsData[0].length];
		  for (int i = 0; i<xlsData[0].length; i++) {
			  xls1[i] = xlsData[0][i];
		  }
		  
		  String[] xls2 = new String[xlsData[1].length];
		  for (int i = 0; i<xlsData[1].length; i++) {
			  xls2[i] = xlsData[1][i];
		  }
		  
		  int aLen = xls1.length;
		  int bLen = xls2.length;
		  
		  String[] xlsLong = new String[aLen+bLen];
		  System.arraycopy(xls1, 0, xlsLong, 0, aLen);
		  System.arraycopy(xls2, 0, xlsLong, aLen, bLen);
		  
		  // find unique values in 1d array
		  Set<String> temp = new LinkedHashSet<String>( Arrays.asList( xlsLong ) );
		  String[] fullnames = temp.toArray( new String[temp.size()] );
		
		  // remove any null values
		  names = new String[0];
		  for (int i=0; i<fullnames.length; i++) {
			  if (fullnames[i] != null) {
				  names = Arrays.copyOf(names, names.length+1);
				  int l = names.length; 
		  		  names[l-1] = fullnames[i];
			  }
		  }	
		  numVertices = names.length;
		  System.out.println("Found " + numVertices + " unique nodes");
		  return names;
	}
	
	public boolean[][] getAdjacency() {
		
		// Assume directed network			  
		  Adjacency = new boolean[numVertices][numVertices];
		  edgeCount = 0;
			 // scan cells of adjacency matrix
		  for (int i = 0; i<names.length; i++) {
			  for (int j = 0; j<names.length; j++) {
				boolean ii = false;
				// scan rows of xlsData for node pair corresponding to current adjacency cell
				for (int k = 0; k<xlsData[0].length; k++) {
					if (xlsData[0][k] == names[i]) {
						if (xlsData[1][k] == names[j]) {
							ii = true;							
							Adjacency[i][j] = true;
							edgeCount = edgeCount+1;
							
						}
					} 
				}								
					if (!ii) {
						Adjacency[i][j] = false;
					}											
			  }
		  }
		  System.out.println("Adjacency Matrix Created");	
		  System.out.println("Found "+ edgeCount + " edges");
		  
		  return Adjacency;
	}
	
	
	public int[] degree(int index)
	{
        	int numNeighborsIn = 0;
        	int numNeighborsOut = 0;

		// Scan row/column of vertex in the adjacency matrix, counting the number of neighbors. 
        // Do this for the two triangles of the matrix. 
        	for (int j = 0; j <= index; j++)
        		if(Adjacency[index][j])
            			numNeighborsOut++;
        
        	for (int j = index+1; j < numVertices; j++)
        		if(Adjacency[j][index])
        			numNeighborsIn++;
        	
        	for (int j = 0; j <= index; j++)
        		if(Adjacency[j][index])
            			numNeighborsIn++;
        
        	for (int j = index+1; j < numVertices; j++)
        		if(Adjacency[index][j])
        			numNeighborsOut++;
        	
        	int[] numNeighbors = new int[2];
        	numNeighbors[0]=numNeighborsOut;
        	numNeighbors[1]=numNeighborsIn;
        	return numNeighbors;	
	} // end degree
	
	public float clusteringCoefficient(int i)
	{

		// Get the indices of the neighbors of vertex i
		int[] neighbors = getNeighbors(i);

		// initialize number of edges-in-neighborhood to 0
		int edgesInNbd = 0;

		// Scan pairs of neighbors and increment counter whenever
		// there is an edge
		for(int j = 0; j < neighbors.length; j++)
			for(int k = 0; k < j; k++)
			{
				// Give names to the indices of the jth neighbor and the kth neighbor
				int vj = neighbors[j];
				int vk = neighbors[k];

				// Check the appropriate slot of the Edges matrix to check
				// if there is an edge between vertices vj and vk
				if((vj >= vk)&&(Adjacency[vj][vk]))
					edgesInNbd++;
				if((vj < vk)&&(Adjacency[vk][vj]))
					edgesInNbd++;
					
			}

		// if there are no neighbors or one neighbor then, clustering 
		// coefficient is trivially defined to  be 1. Otherwise, 
		// compute the ratio of number of edges in neighborhood to 
		// the total number of pairs of neighbors
		if(neighbors.length <= 1)
			return 1;
		else 
			return (float) (edgesInNbd*2.0/(neighbors.length*(neighbors.length-1)));

	}
	
	public int[] getNeighbors(int index)
	{
    	int[] _numNeighbors = degree(index);
    	int numNeighbors = _numNeighbors[0] + _numNeighbors[1];
    	int[] neighbors = new int[numNeighbors];

	// Scan the row corresponding to vertex in the adjacency matrix 
    	numNeighbors = 0;
    
    	for(int j = 0; j < numVertices; j++)
    	{
    		boolean edge = false;
    		if (j <= index) edge = Adjacency[index][j];
			else edge = Adjacency[j][index];

    		if(edge)
        			neighbors[numNeighbors++] = j;
    	}
    	return neighbors;
	}
	
} // end class Network
