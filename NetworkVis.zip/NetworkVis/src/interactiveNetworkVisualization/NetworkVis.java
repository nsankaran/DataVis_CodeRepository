package interactiveNetworkVisualization;

import processing.core.*;
import controlP5.*;

import java.awt.Toolkit;
import java.io.*;
import java.util.*;

/**
 *  Main class for visualizing network.
 */
public class NetworkVis extends PApplet {
	
	java.awt.Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	double screenWidth = screenSize.getWidth();
	double screenHeight = screenSize.getHeight();
	
	// Main object variables:	
	Network myNetwork; // nuts & bolts of network computation
	hivePlot myhivePlot; // nuts & bolts of drawing
	Edge[] allEdges; // bezier curves
	ExcelRead xlssheet;
	ControlP5 cp5;
	
	// Display variables:
    float f1;
    float f2;
    int windowSize;
    
	String[][] xlsData;
	protected String[] names;	// 1-d array to store the nodes
	protected int numVertices;
	protected int[] axisNumber; // assignment of node to axis
	int[][] nodeDegree;
	float[] clustCoeff;
	protected boolean drawFlg = false;

	Textarea myTextarea;
	int baseEdgeClr; 
	int selectEdgeClr;
	String selectedNode;
	String selectedMethod;
	String textInput;
	int selNodeinput;
		
	  public static void main(String args[]) {
		    PApplet.main(new String[] {"interactiveNetworkVisualization.NetworkVis"});
		    
		  }

	  public void settings() {
		  windowSize = (int) (screenWidth/2); // keep the window square for drawing.
		  size((int) (screenWidth/2), (int) (screenWidth/2));
		  f1 = (float) (height*0.05);
		  f2 =  (float) (height*0.4);
		}
	  
	  public void setup() {	
		  selectInput("Select excel file","fileSelected");
		  baseEdgeClr = getIntFromColor(130,130,130);
		  selectEdgeClr = getIntFromColor(0,0,130);
		  smooth();
		  background(0);
		  frameRate(10);
		  	  
		  cp5 = new ControlP5(this);		    		   
		  }

		  public void draw() {
			  background(0);
			  
		    // If Node information known:		   		    	
		    	if (drawFlg) {
		    		pushMatrix();
				    stroke(255);
				    translate((float)(width/2), (float) (height*0.6));		    		 
				    line(0, -f1, 0, -f2); // axis 1 - source
				    rotate(PI/2);
				    line(0, -f1, 0, -f2); // axis 2 - manager
				    rotate(PI/3);
				    line(0, -f1, 0, -f2); // duplicate manager
				    rotate(PI/2);
				    line(0, -f1, 0, -f2); // axis 3 - sink
				    rotate(2*PI/3); // get back to starting frame
				   
		    		for (int i = 0; i < allEdges.length; i++) {
		    			if (allEdges[i] != null) {
		    				if (selectedNode != null) {
		    					int thisNode = Integer.parseInt(selectedNode);
	    						if (xlsData[1][i] == names[thisNode] || xlsData[0][i] == names[thisNode]) {
	    							allEdges[i].display();	    							
	    						}
		    				} else if (textInput!= null) {
		    					if (xlsData[1][i] == names[selNodeinput] || xlsData[0][i] == names[selNodeinput]) {
	    							allEdges[i].display();
	    						}	    				
		    				} else {allEdges[i].display();	
		    				}
		    			} 
		    		}		    		
		    		popMatrix();
		    		
		    	   } 
		    			   
		  } // end draw
		  	  
		  public void fileSelected(File selection) {
			
			  String path = null;
			 
			  
			  if (selection == null) {
			    println("No file selected.");
			  } else {
			    println("User selected:  " + selection.getAbsolutePath());
			    path = selection.getAbsolutePath();
			  }
			  
			  xlssheet = new ExcelRead(path);
			  xlssheet.createReader();
			  xlssheet.getDimensions();			  
			  xlsData = xlssheet.getxlsData();
			  
			  myNetwork = new Network(xlsData);
			  names = myNetwork.getNodeList();
			  myNetwork.getAdjacency();
			  
			  numVertices = names.length;
			  nodeDegree = new int[numVertices][2];
			  clustCoeff = new float[numVertices];
				
				for(int i = 0; i < numVertices; i++) {									
						nodeDegree[i]=myNetwork.degree(i);
						clustCoeff[i]=myNetwork.clusteringCoefficient(i);
						println(names[i]+" degreeIn: "+nodeDegree[i][1]+" degreeOut: "+nodeDegree[i][0]+" Clustering Coeff: "+clustCoeff[i]);
					
					}
				
			 // ------------------- Create GUI components ----------------------------- 			  
			  List<String> coordMethods = Arrays.asList("degree", "clusteringcoefficient");
			  List<String> l = Arrays.asList(names);
			  
			  ScrollableList a = cp5.addScrollableList("nodelist")
			     .setPosition(20,150)
			     .setSize(200, 100)
			     .setBarHeight(20)
			     .setItemHeight(20)
			     .addItems(l)
			     .hide()
			     ;
			  
			  ScrollableList b = cp5.addScrollableList("coordMapping")
			     .setPosition(20,50)
			     .setSize(200, 100)
			     .setBarHeight(20)
			     .setItemHeight(20)
			     .addItems(coordMethods)
			     .hide()
			     ;
			  
			  Textfield c = cp5.addTextfield("input")
			     .setPosition((float)(width-220),(float)(50))
			     .setSize(200,40)			     
			     .setFocus(true)
			     .setColor(color(255,0,0))
			     .hide()
			     ;
			  
			  myTextarea = cp5.addTextarea("txt")
	                  .setPosition((float)(width-220),(float)(150))
	                  .setSize(200,100)
	                  .setFont(createFont("arial",12))
	                  .setLineHeight(14)
	                  .setColor(color(128))
	                  .setColorBackground(color(255,100))
	                  .setColorForeground(color(255,100))
			  		  .hide()		  		
	                  ;
			  			  	                  
	                  // create new Timer task - currently not implemented!
	                  TimerTask task = new FileWatcher( new File(path), path);
	                  // create timer
	                  Timer timer = new Timer();	                  
	                  timer.schedule( task, new Date(), 10 ); // check every 10ms
	                  	             	                  
	                  myhivePlot = new hivePlot(this,names,nodeDegree,clustCoeff,xlsData,selectedMethod,selectedNode,textInput,windowSize,f1,f2);
	                  axisNumber = myhivePlot.getAxis();
	                  allEdges = myhivePlot.makeHive();
	                  drawFlg = myhivePlot.drawFlag();
	                  
	                  
	                  // hiding the components until here becasue it seems to help with "animation thread" errors.
	                  a.show();
	    			  b.show();
	    			  c.show();
	    			  myTextarea.show();
		  			  
		  }
		  		
		public int getIntFromColor(float Red, float Green, float Blue){
		    int R = Math.round(255 * Red);
		    int G = Math.round(255 * Green);
		    int B = Math.round(255 * Blue);

		    R = (R << 16) & 0x00FF0000;
		    G = (G << 8) & 0x0000FF00;
		    B = B & 0x000000FF;

		    return 0xFF000000 | R | G | B;
		}
	
		
// GUI callback functions-----------------------------------------------------
		
		public void coordMapping(int method ) {
	  		  
			  selectedMethod = cp5.get(ScrollableList.class,"coordMapping").getItem(method).get("name").toString();
			  println(selectedMethod);
			  textInput = null;
			  selectedNode = null;
			  
			  System.out.println("Using " + selectedMethod + " for location on axis");
			  			  			  
			  myhivePlot.reHive(selectedMethod);
			  allEdges = myhivePlot.makeHive();
			  							  
			}
		
		public void nodelist(int n) {
			  		  
			  selectedNode = cp5.get(ScrollableList.class,"nodelist").getItem(n).get("value").toString();
			  textInput = null;
			  String function = null;
			  int selNode = Integer.parseInt(selectedNode);			  
			  if (axisNumber[selNode] == 1) {
					function = "Source";
				}else if(axisNumber[selNode] == 2) {
					function = "Manager";
				}else if(axisNumber[selNode] == 3) {
					function = "Sink";
				}
			  String degree = String.valueOf(nodeDegree[selNode][0] + nodeDegree[selNode][1]);
			  String cc = String.valueOf(clustCoeff[selNode]);
			  myTextarea.setText(names[selNode]+" "+function+ " Degree: "+degree+" Clustering Coeff: "+cc);
			  			  								
			  System.out.println("showing connections for " + names[n]);
			  
			  allEdges = myhivePlot.makeHive();
			  							  
			}
		
		public void input(String text) {
			selectedNode = null;
			  // receives results from controller input
			  println("user entered: "+ text);
			  textInput = text;
			  // get index of node			 
			  for (int n=0; n<numVertices; n++){
				  if(textInput.equals(names[n])) {
					  selNodeinput = n;
				  }
			  }	
			  
			  String function = null;			  
			  if (axisNumber[selNodeinput] == 1) {
					function = "Source";
				}else if(axisNumber[selNodeinput] == 2) {
					function = "Manager";
				}else if(axisNumber[selNodeinput] == 3) {
					function = "Sink";
				}
			  String degree = String.valueOf(nodeDegree[selNodeinput][0] + nodeDegree[selNodeinput][1]);
			  String cc = String.valueOf(clustCoeff[selNodeinput]);
			  myTextarea.setText(names[selNodeinput]+" "+function+ " Degree: "+degree+" Clustering Coeff: "+cc);
			  
			  allEdges= myhivePlot.makeHive();			  
			}
				
} // end of class NetworkVis

