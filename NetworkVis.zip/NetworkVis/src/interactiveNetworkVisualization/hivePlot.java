package interactiveNetworkVisualization;

import processing.core.*;

/**
 *  Nuts & bolts of drawing a hiveplot:
 *  More GUI options could be added to allow different methods of axis assignment (e.g. a slider
 *  to specify thresholds like "if clustcoeff > 0.7 then axis 1 etc.."
 *  
 */
public class hivePlot {
	int[] axisNumber;
	String[] names;
	int[][] nodeDegree;
	float[] clustCoeff;
	Edge[] allEdges = new Edge[20000]; // create more than we'll need
	String[][] xlsData;
	String selectedMethod;
	String selectedNode;
	String textInput;
	int selNodeinput;
	int maxDegree;
	float maxclustCoeff;
	int baseEdgeClr;
	int selectEdgeClr;
	int windowSize;
	float f1; // axis constants
	float f2;
	PApplet parent;
	
	public hivePlot(PApplet _parent, String[] _names,int[][] _nodeDegree, float[] _clustCoeff,String[][] _xlsData,String _selectedMethod,String _selectedNode, String _textInput, int _windowSize, float _f1, float _f2) {
		names = _names; nodeDegree = _nodeDegree;
		clustCoeff = _clustCoeff; xlsData = _xlsData;
		selectedMethod = _selectedMethod; selectedNode = _selectedNode;
		textInput = _textInput;
		windowSize = _windowSize; f1 = _f1; f2 = _f2;
		parent = _parent;
		
	}
	
	/**
	 *  Normalize axis mapping to the max value of whatever method specified by GUI scrollList (default = degree). 
	 *  Assign each node to an axis based on whetehr source, sink or manager.
	 */
	public int[] getAxis() {
		int numVertices = names.length;
		maxDegree = 0;
		maxclustCoeff = 0;
		axisNumber = new int[numVertices];
		for (int i=0; i<numVertices; i++) {
			int deg = nodeDegree[i][0] + nodeDegree[i][1];
			if (deg > maxDegree) {
				maxDegree = deg; }
			if (clustCoeff[i] > maxclustCoeff) {
				maxclustCoeff = clustCoeff[i]; }
			if (nodeDegree[i][0] == 0 && nodeDegree[i][1] != 0) {// no edges out then sink
				axisNumber[i] = 3;}
			else if (nodeDegree[i][1] == 0 && nodeDegree[i][0] != 0){ // no edges in then source
				axisNumber[i] = 1;}
			else if (nodeDegree[i][1] != 0 && nodeDegree[i][0] != 0) {
				axisNumber[i] = 2; } // if both in and out edges then manager
			else {}
		}
		
		System.out.println("Max Degree: " + maxDegree);
		System.out.println("Max Clustering Coefficient: " + maxclustCoeff);
		return axisNumber;
	}
	/**
	 * Coordinate specification of each curve. Scan rows of the xls file.
	 * Ideally we would use the adjacency matrix instead of xlsData. The directionality of
	 * each Edge is from left column to right in xlsData. By definition, sinks can't have out edges
	 * and sources can't have in edges. If a connection is from manager to manager, use the duplicate axis.
	 * Handle manager axis assignment to avoid edges crossing axes.
	 *
	 * @return array of Edge objects
	 */
	public Edge[] makeHive() {
		baseEdgeClr = getIntFromColor(130,130,130);
		selectEdgeClr = getIntFromColor(0,0,130);
		int numVertices = names.length;
		float PI = PConstants.PI;
		
		// Loop edges - ideal adjacency matrix instead of xlsData.
		for (int i = 0; i<xlsData[0].length; i++) {
			//ignore null rows
			int inDeg = 0; int outDeg = 0; int inAx = 0; int outAx = 0;
			float outcc = 0; float incc = 0; 
			float xIn = 0; float yIn = 0; float xOut=0; float yOut=0;
			
			if (xlsData[0][i] != null && xlsData[1][i] != null) {
				// find axis and node degree.
				for (int n = 0; n<numVertices; n++) {
					if (xlsData[0][i] == names[n]) { // node with edge out
						outAx = axisNumber[n];	    						
						outDeg = nodeDegree[n][0] + nodeDegree[n][1];
						outcc = clustCoeff[n];
						if (outAx ==3) {
							System.out.println("error: Edge going out of sink found");
						}
					} else if (xlsData[1][i] == names[n]) { // node with edge in
						inAx = axisNumber[n];
						inDeg = nodeDegree[n][0] + nodeDegree[n][1];
						incc = clustCoeff[n];
						if (inAx ==1) {
							System.out.println("error: Edge coming into source found");
						}
					}
				}

				// distance along respective axis.
				float inPctg = 0; float outPctg = 0;
				if (selectedMethod != null) {
					if (selectedMethod.equals("degree")) {
						inPctg = ((float) inDeg)/maxDegree;
						outPctg = ((float) outDeg)/maxDegree;
					} else if (selectedMethod.equals("clusteringcoefficient")) {
						inPctg = ((float) incc)/maxclustCoeff;
						outPctg = ((float) outcc)/maxclustCoeff;
					}
				} else { // default method of degree
					inPctg = ((float) inDeg)/maxDegree;
					outPctg = ((float) outDeg)/maxDegree;	
				}
				
				float dIn = (float) ((0.05*windowSize) + (f2-f1)*inPctg);
				float dOut = (float) ((0.05*windowSize) + (f2-f1)*outPctg);
				
				// axis 1 - both nodes can't be sources.
				if (inAx == 1) {
					//error	    					
				} else 
				if (outAx == 1) {
					xOut = 0; yOut = dOut;
				}
				
				// Axis 3 - both nodes can't be sinks
				if (inAx == 3) {
					xIn = -dIn*PApplet.cos(PI/6); yIn = -dIn*PApplet.sin(PI/6); 
				} else if (outAx == 3) {
					//error
				}
				
				// Axis 2.
				if (inAx == 2) {
					// if coming from axis 1 then use the axis at pi/2.
					if (outAx == 1) {
						xIn = dIn; yIn = 0;	    				
					} else if (outAx == 3) {	    												
						//error    					
					}
					// if both managers then use both axes.
					else if (outAx == 2) {
						xIn = dIn; yIn = 0;
						xOut = dOut*PApplet.cos(PI/3); yOut = - dOut*PApplet.sin(PI/3); 
					}
				} 
				if (outAx ==2) {
					
					if (inAx == 1) {
						//error	    					
					} // if going to axis 3 then use the axis at 5pi/6.
					else if (inAx == 3) {
						xOut = dOut*PApplet.cos(PI/3); yOut = - dOut*PApplet.sin(PI/3);	    					
					} 		    						    					
				}
				// initialize this edge	    				
					if (selectedNode != null) {
						int thisNode = Integer.parseInt(selectedNode);
						if (xlsData[1][i] == names[thisNode] || xlsData[0][i] == names[thisNode]) {
							allEdges[i] = new Edge(parent,xIn, -yIn, xIn, -yOut, xOut, -yOut, xOut, -yOut,selectEdgeClr);
						}
					} else if (textInput != null) {
						  for (int n=0; n<numVertices; n++){
							  if(textInput.equals(names[n])) {
								  selNodeinput = n;
							  }
						  }
						if (xlsData[1][i] == names[selNodeinput] || xlsData[0][i] == names[selNodeinput]) {
							allEdges[i] = new Edge(parent,xIn, -yIn, xIn, -yOut, xOut, -yOut, xOut, -yOut,selectEdgeClr);
						}	
					}
					else {
					allEdges[i] = new Edge(parent,xIn, -yIn, xIn, -yOut, xOut, -yOut, xOut, -yOut,baseEdgeClr);
					}	    						    		
			}
		} 
		
		return allEdges;
	} // end makeHive()
	
	// if we change mapping methods we don't want to create a whole new hive object.
	public void reHive(String _selectedMethod) {
		selectedMethod = _selectedMethod;
	}
	
	// call this method to tell sketch that it can draw.
	public boolean drawFlag() {
	boolean drawFlg = true;
	return drawFlg;
	}
	
	public int getIntFromColor(float Red, float Green, float Blue){
	    int R = Math.round(255 * Red);
	    int G = Math.round(255 * Green);
	    int B = Math.round(255 * Blue);

	    R = (R << 16) & 0x00FF0000;
	    G = (G << 8) & 0x0000FF00;
	    B = B & 0x000000FF;

	    return 0xFF000000 | R | G | B;
	}
	
} // end class hivePlot
